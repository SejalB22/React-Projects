import product1 from "./assets/products/1.png";
import product2 from "./assets/products/2.png";
import product3 from "./assets/products/3.png";
import product4 from "./assets/products/4.png";
import product5 from "./assets/products/5.png";
import product6 from "./assets/products/6.webp";
import product7 from "./assets/products/7.webp";
import product8 from "./assets/products/8.webp";
import product9 from "./assets/products/9.png";
import product10 from "./assets/products/10.png";
import product11 from "./assets/products/11.png";
import product12 from "./assets/products/12.png";
import product13 from "./assets/products/13.png";
import product14 from "./assets/products/14.png";
import product15 from "./assets/products/15.png";
import product16 from "./assets/products/16.png";
import product17 from "./assets/products/17.png";
import product18 from "./assets/products/18.webp";

export const PRODUCTS = [
  {
    id: 1,
    productName: "IPhone",
    price: 80000,
    productImage: product1,
  },
  {
    id: 2,
    productName: "Macbook Pro 2022 (M1)",
    price: 149000,
    productImage: product2,
  },
  {
    id: 3,
    productName: "Cannon M50 Camera",
    price: 52000,
    productImage: product3,
  },
  {
    id: 4,
    productName: "WLS Van Gogh Denim Jacket",
    price: 3000,
    productImage: product4,
  },
  {
    id: 5,
    productName: "LED Light Strips",
    price: 400,
    productImage: product5,
  },
  {
    id: 6,
    productName: "SPECTRUM LS TEE",
    price: 900,
    productImage: product6,
  },
  {
    id: 7,
    productName: "AUTO SERVICE SHIRT by GOLF WANG",
    price: 3400,
    productImage: product7,
  },
  {
    id: 8,
    productName: "DON'T TRIP UNSTRUCTURED HAT",
    price: 800,
    productImage: product8,
  },
  {
    id: 9,
    productName: "NIKI fit shoes",
    price: 70000,
    productImage: product9,
  },
  {
    id: 10,
    productName: "Jbl Speakers",
    price: 25000,
    productImage: product10,
  },
  {
    id: 11,
    productName: "Diesel  bag",
    price: 30000,
    productImage: product11,
  },
  {
    id: 12,
    productName: "Zara Purse",
    price: 40000,
    productImage: product12,
  },
  {
    id: 13,
    productName: "Ganpati bronze idol",
    price: 4000,
    productImage: product13,
  },
  {
    id: 14,
    productName: "Garnier puer active Face-Wash",
    price: 45000,
    productImage: product14,
  },
  {
    id: 15,
    productName: "Mens grey Shirt",
    price: 50000,
    productImage: product15,
  },
  {
    id: 16,
    productName: "black shades",
    price: 120000,
    productImage: product16,
  },
  {
    id: 17,
    productName: "hill footware",
    price: 15000,
    productImage: product17,
  },
  {
    id: 18,
    productName: "Sony PS 5",
    price: 12000,
    productImage: product18,
  },
];
