import React, { useState } from "react";

export const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
    // You can add code here to send the form data to a server or an email service
    alert('Form submitted!');
  };

  const styles = {
    contactPage: {
      maxWidth: '600px',
      margin: '0 auto',
      padding: '1em',
      fontFamily: 'Arial, sans-serif'
    },
    title: {
      textAlign: 'center',
      marginBottom: '1em'
    },
    formGroup: {
      marginBottom: '1em'
    },
    label: {
      display: 'block',
      marginBottom: '0.5em'
    },
    input: {
      width: '100%',
      padding: '0.5em',
      boxSizing: 'border-box',
      marginBottom: '1em'
    },
    textarea: {
      width: '100%',
      padding: '0.5em',
      boxSizing: 'border-box',
      height: '150px'
    },
    button: {

      display: 'block',
      width: '100%',
      padding: '1em',
      backgroundColor: 'black',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
      fontSize: '1em',
      textAlign: 'center'
    },
    buttonHover: {
      backgroundColor: 'grey'
    }
  };

  return (
    <div style={styles.contactPage}>
      <h1 style={styles.title}>Contact Us</h1>
      <form onSubmit={handleSubmit}>
        <div style={styles.formGroup}>
          <label htmlFor="name" style={styles.label}>Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            style={styles.input}
          />
        </div>
        <div style={styles.formGroup}>
          <label htmlFor="email" style={styles.label}>Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            style={styles.input}
          />
        </div>
        <div style={styles.formGroup}>
          <label htmlFor="subject" style={styles.label}>Subject:</label>
          <input
            type="text"
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
            required
            style={styles.input}
          />
        </div>
        <div style={styles.formGroup}>
          <label htmlFor="message" style={styles.label}>Message:</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
            style={styles.textarea}
          ></textarea>
        </div>
        <button
          type="submit"
          style={styles.button}
          onMouseOver={(e) => (e.target.style.backgroundColor = styles.buttonHover.backgroundColor)}
          onMouseOut={(e) => (e.target.style.backgroundColor = styles.button.backgroundColor)}
        >
          Submit
        </button>
      </form>
    </div>
  );
};
